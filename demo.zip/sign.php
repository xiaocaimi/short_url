<?php
// demo 演示
class Sign{
    private $appId;
    private $appSecret;
    private $time;

    public function __construct($appId, $appSecret,$time)
    {
        $this->appId = $appId;
        $this->appSecret = $appSecret;
        $this->time = $time;
    }

    public function getKey()
    {
        // 读取文件缓存
        $cache = json_decode( @file_get_contents('fileCache.json'),true );
        if( $cache['time'] < time() ){
            $url = "http://dwz.lt/api?mod=getSign";
            $param['appid'] = $this->appId;
            $param['appsecret'] = $this->appSecret;
            $param['time'] = $this->time;
            $res = json_decode( $this->httpPost($url,$param),true );
            if( $res['status'] ){
                $key = $res['key'];
                if( $key ){
                   $keyArr['key'] = $key;
                   $keyArr['time'] = $res['post_time'] + 7000;
                   @file_put_contents('fileCache.json',json_encode($keyArr)); 
                }
            }else{
                $key = $res;
            }
        }else{
            $key = $cache['key'];
        }

        return $key;
    }

    /**
     * 发送HTTP请求方法
     * @param  string $url    请求URL
     * @param  array|string  $params 请求参数
     * @return array  $data   响应数据
     */
    private function httpPost($url,$params)
    {
        $opts = array(
                CURLOPT_URL => $url,
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => $params,
                CURLOPT_TIMEOUT        => 500,
                CURLOPT_RETURNTRANSFER => 1
            );

        // 判断是否https
        if( parse_url($url)['scheme'] == 'https' ){
            $opts[CURLOPT_SSL_VERIFYPEER] = true;
            $opts[CURLOPT_SSL_VERIFYHOST] = true;
        }else{
            $opts[CURLOPT_SSL_VERIFYPEER] = false;
            $opts[CURLOPT_SSL_VERIFYHOST] = false;
        }
        /* 初始化并执行curl请求 */
        $ch = curl_init();
        curl_setopt_array($ch, $opts);
        $res  = curl_exec($ch);
        curl_close($ch);
        return  $res;
    }

    public function httpGet($url) {
        $opts = array(
                CURLOPT_URL => $url,
                CURLOPT_TIMEOUT        => 500,
                CURLOPT_RETURNTRANSFER => 1
            );

        // 判断是否https
        if( parse_url($url)['scheme'] == 'https' ){
            $opts[CURLOPT_SSL_VERIFYPEER] = true;
            $opts[CURLOPT_SSL_VERIFYHOST] = true;
        }else{
            $opts[CURLOPT_SSL_VERIFYPEER] = false;
            $opts[CURLOPT_SSL_VERIFYHOST] = false;
        }
        

        /* 初始化并执行curl请求 */
        $ch = curl_init();
        curl_setopt_array($ch, $opts);
        $res  = curl_exec($ch);
        curl_close($ch);
        return  $res;
    }
}
