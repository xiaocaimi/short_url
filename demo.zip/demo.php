<?php
    header("content-type:text/html;charset=utf-8");
    error_reporting(0);
    require_once "sign.php";
    $sign = new Sign("dwz_2XKpa2naxn5k","oQB4dMW7eXJ8Ava2Ramp61DVE5jGrwbR",time());
    $key = $sign->getKey();
    if(is_array($key)){echo "<div style='font-size:36px;color:red;margin-top:30px;'>{$key['info']}</div>";}
    // 方法1 php处理url
    if( $_GET['type'] ){
    	$url = "http://dwz.lt/api?mod={$_GET['type']}&type=json&key={$key}&url={$_GET['url']}";
    	$res = json_decode($sign->httpGet($url),true);
    }

    

?>
<!DOCTYPE html>
<html lang="en">
	<head>
	  	<meta charset="UTF-8">
	  	<title>短网址Api demo</title>
	</head>
	<body style="margin:0px auto;text-align:center;">
		<br/><br/>方法1：<br/><br/>
		<form action="demo.php" method="get">
			<input type="text" name="url" <?php if($_GET['type'] == 'shorten'){echo "value='{$res['url']}'";} ?>>
			<input type="hidden" name="type" value="shorten" >
			<input type="submit" name="submit" value="生成短网址">
		</form>
		<div><?php if($_GET['type'] == 'shorten') echo $res['short_url']; ?></div>
		<br/>
		<form action="demo.php" method="post">
			<input type="text" name="url" <?php if($_GET['type'] == 'expand'){echo "value='{$res['short_url']}'";} ?>>
			<input type="hidden" name="type" value="expand" >
			<input type="submit" name="submit" value="解析短网址">
		</form>
		<div><?php if($_GET['type'] == 'expand') echo $res['url']; ?></div><br/>
  		<hr/><br/>
  		方法2：<br/><br/>
  		<input type="text" id="url1">
		<input type="hidden" id="key" value="<?php echo $key;?>" >
  		<br/><br/>
  		<input type="button" id="shorten" onclick="getJsonp(this)" value="生成短网址">
  		<input type="button" id="expand" onclick="getJsonp(this)" value="解析短网址">
  		<br/><br/>
  		结果：<br/><br/>
  		<input type="text" id="url2">
	</body>
	<script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
	<script>
		// 方法2 jsonp获取
		function getJsonp(_this){
			var url = $('#url1').val();
			var mod = $(_this).attr('id');
			var key = $('#key').val();
			url = "http://dwz.lt/api?mod="+mod+"&type=jsonp&key="+key+"&url="+url;
			$.getJSON(url+'&callback=?',function(data){
				if( data.status == 1 ){
					if( mod == 'shorten' ){
			        	$('#url2').val(data.short_url);
			        }else{
			        	$('#url2').val(data.url);
			        }
				}else{
					alert(data.info);
				}
		    }) 
		}
		
	</script>
</html>


